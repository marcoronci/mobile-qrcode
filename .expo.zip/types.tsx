export type RootStackParamList = {
  Root: undefined;
  NotFound: undefined;
};

export type BottomTabParamList = {
  BarCodeScan: undefined;
  About: undefined;
};

export type BarCodeScanParamList = {
  BarCodeScanScreen: undefined;
};

export type AboutParamList = {
  AboutScreen: undefined;
};
